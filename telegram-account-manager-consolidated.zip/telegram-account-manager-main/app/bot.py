import asyncio
import json
import uuid
from datetime import datetime, timezone

import redis.asyncio as redis
from aiogram import Bot, Dispatcher
from aiogram.client.default import DefaultBotProperties
from aiogram.enums import ParseMode
from aiogram.filters import Command, CommandStart
from aiogram.types import Message
from sqlalchemy import func, select, text

from .config import (
    ADMIN_IDS,
    BOT_TOKEN,
    HEALTH_INTERVAL_SECONDS,
    JOB_RETRY_DELAY_SECONDS,
    REDIS_URL,
    WORKER_NAME,
    WORKER_POLL_SECONDS,
)
from .database import SessionLocal, engine
from .models import (
    AccountTag,
    Admin,
    AuditLog,
    Base,
    HealthCheck,
    Job,
    ManagedAccount,
    SystemSetting,
    TelegramGroup,
    WorkerHeartbeat,
)


QUEUE_KEY = "account_manager:jobs"
dp = Dispatcher()
redis_client: redis.Redis | None = None


def now_utc() -> datetime:
    return datetime.now(timezone.utc)


def is_admin(message: Message) -> bool:
    return bool(message.from_user and message.from_user.id in ADMIN_IDS)


async def require_admin(message: Message) -> bool:
    if not is_admin(message):
        await message.answer("⛔ Unauthorized.")
        return False
    return True


async def init_redis() -> None:
    global redis_client
    redis_client = redis.from_url(REDIS_URL, decode_responses=True)
    await redis_client.ping()
    print("🔴 Redis connected")


async def close_redis() -> None:
    global redis_client
    if redis_client is not None:
        await redis_client.aclose()
        redis_client = None


async def queue_length() -> int:
    if redis_client is None:
        return 0
    return int(await redis_client.llen(QUEUE_KEY))


async def emergency_stopped() -> bool:
    async with SessionLocal() as session:
        result = await session.execute(
            select(SystemSetting.value).where(SystemSetting.key == "emergency_stop")
        )
        value = result.scalar_one_or_none()
    return str(value).lower() == "true" if value is not None else False


async def set_emergency_stop(stopped: bool) -> None:
    async with SessionLocal() as session:
        result = await session.execute(
            select(SystemSetting).where(SystemSetting.key == "emergency_stop")
        )
        setting = result.scalar_one_or_none()
        if setting is None:
            setting = SystemSetting(key="emergency_stop", value="false")
            session.add(setting)
        setting.value = "true" if stopped else "false"
        await session.commit()


async def add_log(admin_id: int, action: str, target: str | None = None, details: str | None = None) -> None:
    async with SessionLocal() as session:
        session.add(AuditLog(admin_id=admin_id, action=action, target=target, details=details))
        await session.commit()


async def create_tables() -> None:
    async with engine.begin() as connection:
        await connection.run_sync(Base.metadata.create_all)

        # Compatibility migrations for databases created by the earlier version.
        await connection.execute(text("ALTER TABLE managed_accounts ADD COLUMN IF NOT EXISTS health VARCHAR(50) NOT NULL DEFAULT 'unknown'"))
        await connection.execute(text("ALTER TABLE managed_accounts ADD COLUMN IF NOT EXISTS last_health_check TIMESTAMPTZ"))
        await connection.execute(text("ALTER TABLE managed_accounts ADD COLUMN IF NOT EXISTS last_seen TIMESTAMPTZ"))
        await connection.execute(text("ALTER TABLE managed_accounts ADD COLUMN IF NOT EXISTS reconnect_attempts INTEGER NOT NULL DEFAULT 0"))
        await connection.execute(text("ALTER TABLE managed_accounts ADD COLUMN IF NOT EXISTS updated_at TIMESTAMPTZ DEFAULT NOW()"))
        await connection.execute(text("CREATE INDEX IF NOT EXISTS ix_managed_accounts_status ON managed_accounts(status)"))
        await connection.execute(text("CREATE INDEX IF NOT EXISTS ix_managed_accounts_health ON managed_accounts(health)"))
        await connection.execute(text("CREATE INDEX IF NOT EXISTS ix_audit_logs_created_at ON audit_logs(created_at)"))

    async with SessionLocal() as session:
        for telegram_id in ADMIN_IDS:
            result = await session.execute(select(Admin).where(Admin.telegram_id == telegram_id))
            if result.scalar_one_or_none() is None:
                session.add(Admin(telegram_id=telegram_id))

        setting_result = await session.execute(select(SystemSetting).where(SystemSetting.key == "emergency_stop"))
        if setting_result.scalar_one_or_none() is None:
            session.add(SystemSetting(key="emergency_stop", value="false"))
        await session.commit()


async def create_job(
    job_type: str,
    created_by: int,
    account_id: int | None = None,
    target_id: int | None = None,
    payload: dict | None = None,
    max_attempts: int = 3,
) -> str:
    if redis_client is None:
        raise RuntimeError("Redis is not connected")

    job_id = uuid.uuid4().hex[:16]
    job = Job(
        job_id=job_id,
        job_type=job_type,
        status="queued",
        account_id=account_id,
        target_id=target_id,
        payload=json.dumps(payload or {}),
        created_by=created_by,
        max_attempts=max_attempts,
    )

    async with SessionLocal() as session:
        session.add(job)
        await session.commit()

    queue_item = {
        "job_id": job_id,
        "type": job_type,
        "created_at": now_utc().isoformat(),
    }
    try:
        await redis_client.rpush(QUEUE_KEY, json.dumps(queue_item))
    except Exception:
        async with SessionLocal() as session:
            result = await session.execute(select(Job).where(Job.job_id == job_id))
            db_job = result.scalar_one_or_none()
            if db_job:
                db_job.status = "failed"
                db_job.error = "Could not enqueue job in Redis"
                db_job.finished_at = now_utc()
                await session.commit()
        raise

    return job_id


async def heartbeat(status: str, current_job_id: str | None = None) -> None:
    async with SessionLocal() as session:
        result = await session.execute(select(WorkerHeartbeat).where(WorkerHeartbeat.worker_name == WORKER_NAME))
        row = result.scalar_one_or_none()
        if row is None:
            row = WorkerHeartbeat(worker_name=WORKER_NAME, status=status, current_job_id=current_job_id)
            session.add(row)
        else:
            row.status = status
            row.current_job_id = current_job_id
            row.last_seen = now_utc()
        await session.commit()


async def process_health_job(job_id: str) -> dict:
    async with SessionLocal() as session:
        result = await session.execute(select(Job).where(Job.job_id == job_id))
        job = result.scalar_one_or_none()
        if job is None:
            raise RuntimeError("Job not found")
        if job.account_id is None:
            raise RuntimeError("Health job has no account")

        account_result = await session.execute(select(ManagedAccount).where(ManagedAccount.id == job.account_id))
        account = account_result.scalar_one_or_none()
        if account is None:
            raise RuntimeError("Account not found")

        checked_at = now_utc()
        if account.status == "disconnected":
            health = "offline"
            details = "Account is marked disconnected in the manager."
        elif account.status == "active":
            health = "healthy"
            account.last_seen = checked_at
            details = "Manager-side account record is active. No Telegram login/session validity is verified by this check."
        else:
            health = "unknown"
            details = "Account is pending and has not been activated."

        account.health = health
        account.last_health_check = checked_at
        account.updated_at = checked_at
        session.add(HealthCheck(account_id=account.id, status=health, details=details, checked_at=checked_at))
        await session.commit()

    return {"health": health, "details": details}


async def process_job(job_id: str) -> None:
    async with SessionLocal() as session:
        result = await session.execute(select(Job).where(Job.job_id == job_id))
        job = result.scalar_one_or_none()
        if job is None or job.status in {"completed", "cancelled"}:
            return
        job.status = "running"
        job.attempts += 1
        job.started_at = now_utc()
        await session.commit()
        job_type = job.job_type

    await heartbeat("busy", job_id)

    try:
        if job_type == "health_check":
            result_data = await process_health_job(job_id)
        else:
            raise RuntimeError(f"Unsupported job type: {job_type}")

        async with SessionLocal() as session:
            result = await session.execute(select(Job).where(Job.job_id == job_id))
            job = result.scalar_one_or_none()
            if job:
                job.status = "completed"
                job.result = json.dumps(result_data)
                job.error = None
                job.finished_at = now_utc()
                await session.commit()
    except Exception as exc:
        async with SessionLocal() as session:
            result = await session.execute(select(Job).where(Job.job_id == job_id))
            job = result.scalar_one_or_none()
            if job:
                if job.attempts < job.max_attempts:
                    job.status = "queued"
                else:
                    job.status = "failed"
                    job.finished_at = now_utc()
                job.error = str(exc)[:2000]
                await session.commit()
        if job and job.attempts < job.max_attempts:
            await asyncio.sleep(JOB_RETRY_DELAY_SECONDS)
            if redis_client is not None and not await emergency_stopped():
                await redis_client.rpush(QUEUE_KEY, json.dumps({"job_id": job_id, "type": job_type, "retry": True}))
    finally:
        await heartbeat("idle", None)


async def worker_loop() -> None:
    while True:
        try:
            if await emergency_stopped():
                await heartbeat("paused", None)
                await asyncio.sleep(WORKER_POLL_SECONDS)
                continue

            await heartbeat("idle", None)
            if redis_client is None:
                await asyncio.sleep(WORKER_POLL_SECONDS)
                continue

            item = await redis_client.blpop(QUEUE_KEY, timeout=max(1, int(WORKER_POLL_SECONDS)))
            if not item:
                continue

            _, raw = item
            data = json.loads(raw)
            job_id = data.get("job_id")
            if job_id:
                await process_job(job_id)
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            print(f"Worker error: {exc}")
            await asyncio.sleep(WORKER_POLL_SECONDS)


async def health_scheduler_loop() -> None:
    while True:
        try:
            await asyncio.sleep(HEALTH_INTERVAL_SECONDS)
            if await emergency_stopped():
                continue

            async with SessionLocal() as session:
                result = await session.execute(select(ManagedAccount.id).where(ManagedAccount.status == "active"))
                account_ids = [row[0] for row in result.fetchall()]

            for account_id in account_ids:
                try:
                    await create_job("health_check", 0, account_id=account_id, payload={"scheduled": True}, max_attempts=2)
                except Exception as exc:
                    print(f"Could not schedule health check for {account_id}: {exc}")
        except asyncio.CancelledError:
            raise
        except Exception as exc:
            print(f"Health scheduler error: {exc}")


async def command_account_id(message: Message, usage: str) -> int | None:
    parts = message.text.split(maxsplit=1)
    if len(parts) != 2:
        await message.answer(f"Usage:\n<code>{usage}</code>")
        return None
    try:
        return int(parts[1].strip())
    except ValueError:
        await message.answer("❌ Invalid ID.")
        return None


@dp.message(CommandStart())
async def start_handler(message: Message):
    if not await require_admin(message):
        return
    stopped = await emergency_stopped()
    await message.answer(
        "🤖 <b>Telegram Account Manager</b>\n\n"
        f"{'🔴 EMERGENCY STOP ACTIVE' if stopped else '🟢 System operational'}\n\n"
        "Use /dashboard for the overview or /help for all commands."
    )


@dp.message(Command("help"))
async def help_handler(message: Message):
    if not await require_admin(message):
        return
    await message.answer(
        "🤖 <b>Account Manager — Commands</b>\n\n"
        "📊 <b>System</b>\n"
        "/dashboard — overview\n"
        "/status — full system status\n"
        "/health — account health summary\n"
        "/worker — worker status\n"
        "/queue — Redis queue\n"
        "/stop — pause workers\n"
        "/resume — resume workers\n\n"
        "👥 <b>Accounts</b>\n"
        "/addaccount NAME\n"
        "/accounts [active|pending|disconnected]\n"
        "/account ID\n"
        "/activateaccount ID\n"
        "/disconnect ID\n"
        "/removeaccount ID\n"
        "/note ID TEXT\n"
        "/healthcheck ID — queue one health check\n\n"
        "🏷️ <b>Tags</b>\n"
        "/tag ID TAG\n"
        "/untag ID TAG\n"
        "/tags\n\n"
        "📡 <b>Targets</b>\n"
        "/active TELEGRAM_ID\n"
        "/inactive TELEGRAM_ID\n"
        "/groups\n\n"
        "📦 <b>Jobs</b>\n"
        "/jobs [queued|running|completed|failed|cancelled]\n"
        "/job JOB_ID\n"
        "/canceljob JOB_ID\n"
        "/retryjob JOB_ID\n\n"
        "📜 <b>Administration</b>\n"
        "/logs\n"
        "/help"
    )


@dp.message(Command("dashboard"))
async def dashboard_handler(message: Message):
    if not await require_admin(message):
        return
    async with SessionLocal() as session:
        total = await session.scalar(select(func.count(ManagedAccount.id)))
        active = await session.scalar(select(func.count(ManagedAccount.id)).where(ManagedAccount.status == "active"))
        pending = await session.scalar(select(func.count(ManagedAccount.id)).where(ManagedAccount.status == "pending"))
        disconnected = await session.scalar(select(func.count(ManagedAccount.id)).where(ManagedAccount.status == "disconnected"))
        healthy = await session.scalar(select(func.count(ManagedAccount.id)).where(ManagedAccount.health == "healthy"))
        queued = await session.scalar(select(func.count(Job.id)).where(Job.status == "queued"))
        running = await session.scalar(select(func.count(Job.id)).where(Job.status == "running"))
        failed = await session.scalar(select(func.count(Job.id)).where(Job.status == "failed"))
        targets = await session.scalar(select(func.count(TelegramGroup.id)))
        active_targets = await session.scalar(select(func.count(TelegramGroup.id)).where(TelegramGroup.is_active.is_(True)))
        worker = await session.execute(select(WorkerHeartbeat).where(WorkerHeartbeat.worker_name == WORKER_NAME))
        worker_row = worker.scalar_one_or_none()
    stopped = await emergency_stopped()
    await message.answer(
        "📊 <b>Dashboard</b>\n\n"
        f"Accounts: <code>{total or 0}</code>\n"
        f"🟢 Active: <code>{active or 0}</code>\n"
        f"🟡 Pending: <code>{pending or 0}</code>\n"
        f"🔴 Disconnected: <code>{disconnected or 0}</code>\n"
        f"💚 Healthy: <code>{healthy or 0}</code>\n\n"
        f"Jobs queued: <code>{queued or 0}</code>\n"
        f"Jobs running: <code>{running or 0}</code>\n"
        f"Jobs failed: <code>{failed or 0}</code>\n\n"
        f"Targets: <code>{targets or 0}</code>\n"
        f"Active targets: <code>{active_targets or 0}</code>\n\n"
        f"Worker: <code>{worker_row.status if worker_row else 'starting'}</code>\n"
        f"Emergency stop: {'🔴 ON' if stopped else '🟢 OFF'}"
    )


@dp.message(Command("status"))
async def status_handler(message: Message):
    if not await require_admin(message):
        return
    async with SessionLocal() as session:
        accounts = await session.scalar(select(func.count(ManagedAccount.id)))
        groups = await session.scalar(select(func.count(TelegramGroup.id)))
        jobs = await session.scalar(select(func.count(Job.id)).where(Job.status.in_(["queued", "running"])))
        worker_result = await session.execute(select(WorkerHeartbeat).where(WorkerHeartbeat.worker_name == WORKER_NAME))
        worker = worker_result.scalar_one_or_none()
    stopped = await emergency_stopped()
    await message.answer(
        "📊 <b>System Status</b>\n\n"
        "🤖 Bot: 🟢 Online\n"
        "🗄️ PostgreSQL: 🟢 Connected\n"
        f"🔴 Redis: {'🟢 Connected' if redis_client else '🔴 Offline'}\n\n"
        f"👤 Admins: <code>{len(ADMIN_IDS)}</code>\n"
        f"👥 Accounts: <code>{accounts or 0}</code>\n"
        f"📡 Targets: <code>{groups or 0}</code>\n"
        f"📦 Pending/running jobs: <code>{jobs or 0}</code>\n"
        f"⚙️ Worker: <code>{worker.status if worker else 'starting'}</code>\n"
        f"🛑 Emergency stop: {'🔴 ON' if stopped else '🟢 OFF'}"
    )


@dp.message(Command("worker"))
async def worker_handler(message: Message):
    if not await require_admin(message):
        return
    async with SessionLocal() as session:
        result = await session.execute(select(WorkerHeartbeat).where(WorkerHeartbeat.worker_name == WORKER_NAME))
        row = result.scalar_one_or_none()
    if not row:
        await message.answer("⚙️ Worker has not reported yet.")
        return
    await message.answer(
        "⚙️ <b>Worker</b>\n\n"
        f"Name: <code>{row.worker_name}</code>\n"
        f"Status: <code>{row.status}</code>\n"
        f"Last heartbeat: <code>{row.last_seen}</code>\n"
        f"Current job: <code>{row.current_job_id or 'None'}</code>"
    )


@dp.message(Command("account"))
async def account_handler(message: Message):
    if not await require_admin(message):
        return
    account_id = await command_account_id(message, "/account 1")
    if account_id is None:
        return
    async with SessionLocal() as session:
        result = await session.execute(select(ManagedAccount).where(ManagedAccount.id == account_id))
        account = result.scalar_one_or_none()
        tags_result = await session.execute(select(AccountTag.tag).where(AccountTag.account_id == account_id).order_by(AccountTag.tag))
        tags = [row[0] for row in tags_result.fetchall()]
    if account is None:
        await message.answer("❌ Account not found.")
        return
    await message.answer(
        "👤 <b>Account Details</b>\n\n"
        f"🆔 ID: <code>{account.id}</code>\n"
        f"📌 Name: <b>{account.label}</b>\n"
        f"📊 Status: <code>{account.status}</code>\n"
        f"💚 Health: <code>{account.health}</code>\n"
        f"🏷️ Tags: <code>{', '.join(tags) if tags else 'None'}</code>\n"
        f"🔄 Reconnect attempts: <code>{account.reconnect_attempts}</code>\n"
        f"📝 Notes: <code>{account.notes or 'None'}</code>\n"
        f"❤️ Last health check: <code>{account.last_health_check or 'Never'}</code>\n"
        f"👀 Last seen: <code>{account.last_seen or 'Never'}</code>"
    )


@dp.message(Command("addaccount"))
async def add_account_handler(message: Message):
    if not await require_admin(message):
        return
    parts = message.text.split(maxsplit=1)
    if len(parts) != 2:
        await message.answer("Usage:\n<code>/addaccount Account-001</code>")
        return
    label = parts[1].strip()
    if not label or len(label) > 255:
        await message.answer("❌ Account name must be 1–255 characters.")
        return
    async with SessionLocal() as session:
        account = ManagedAccount(label=label, status="pending", health="unknown", created_by=message.from_user.id)
        session.add(account)
        await session.commit()
        account_id = account.id
    await add_log(message.from_user.id, "ADD_ACCOUNT", str(account_id), label)
    await message.answer(f"✅ <b>Account added</b>\n\nID: <code>{account_id}</code>\nName: <b>{label}</b>\nStatus: 🟡 Pending")


@dp.message(Command("activateaccount"))
async def activate_account_handler(message: Message):
    if not await require_admin(message):
        return
    account_id = await command_account_id(message, "/activateaccount 1")
    if account_id is None:
        return
    async with SessionLocal() as session:
        result = await session.execute(select(ManagedAccount).where(ManagedAccount.id == account_id))
        account = result.scalar_one_or_none()
        if account is None:
            await message.answer("❌ Account not found.")
            return
        account.status = "active"
        account.health = "unknown"
        account.updated_at = now_utc()
        await session.commit()
    await add_log(message.from_user.id, "ACTIVATE_ACCOUNT", str(account_id))
    await message.answer(f"🟢 <b>Account activated</b>\n\nID: <code>{account_id}</code>\nRun /healthcheck {account_id} to queue an immediate manager-side health check.")


@dp.message(Command("accounts"))
async def accounts_handler(message: Message):
    if not await require_admin(message):
        return
    parts = message.text.split(maxsplit=1)
    status_filter = parts[1].strip().lower() if len(parts) == 2 else None
    valid = {"active", "pending", "disconnected"}
    if status_filter and status_filter not in valid:
        await message.answer("Filters: active, pending, disconnected")
        return
    async with SessionLocal() as session:
        stmt = select(ManagedAccount).order_by(ManagedAccount.id.desc())
        if status_filter:
            stmt = stmt.where(ManagedAccount.status == status_filter)
        result = await session.execute(stmt)
        accounts = result.scalars().all()
    if not accounts:
        await message.answer("👥 <b>Accounts</b>\n\nNo accounts found.")
        return
    lines = ["👥 <b>Accounts</b>", ""]
    for account in accounts:
        icon = {"active": "🟢", "pending": "🟡", "disconnected": "🔴"}.get(account.status, "⚪")
        lines.append(f"{icon} <b>{account.label}</b> — <code>{account.id}</code>\nStatus: <code>{account.status}</code> | Health: <code>{account.health}</code>")
    await message.answer("\n\n".join(lines))


@dp.message(Command("disconnect"))
async def disconnect_handler(message: Message):
    if not await require_admin(message):
        return
    account_id = await command_account_id(message, "/disconnect 1")
    if account_id is None:
        return
    async with SessionLocal() as session:
        result = await session.execute(select(ManagedAccount).where(ManagedAccount.id == account_id))
        account = result.scalar_one_or_none()
        if account is None:
            await message.answer("❌ Account not found.")
            return
        account.status = "disconnected"
        account.health = "offline"
        account.updated_at = now_utc()
        await session.commit()
    await add_log(message.from_user.id, "DISCONNECT_ACCOUNT", str(account_id), account.label)
    await message.answer(f"🔴 <b>Account disconnected</b>\n\nID: <code>{account_id}</code>\nName: <b>{account.label}</b>")


@dp.message(Command("removeaccount"))
async def remove_account_handler(message: Message):
    if not await require_admin(message):
        return
    account_id = await command_account_id(message, "/removeaccount 1")
    if account_id is None:
        return
    async with SessionLocal() as session:
        result = await session.execute(select(ManagedAccount).where(ManagedAccount.id == account_id))
        account = result.scalar_one_or_none()
        if account is None:
            await message.answer("❌ Account not found.")
            return
        label = account.label
        await session.delete(account)
        await session.commit()
    await add_log(message.from_user.id, "REMOVE_ACCOUNT", str(account_id), label)
    await message.answer(f"🗑️ <b>Account removed</b>\n\nID: <code>{account_id}</code>\nName: <b>{label}</b>")


@dp.message(Command("note"))
async def note_handler(message: Message):
    if not await require_admin(message):
        return
    parts = message.text.split(maxsplit=2)
    if len(parts) != 3:
        await message.answer("Usage:\n<code>/note 1 Needs review</code>")
        return
    try:
        account_id = int(parts[1])
    except ValueError:
        await message.answer("❌ Invalid account ID.")
        return
    note = parts[2].strip()[:4000]
    async with SessionLocal() as session:
        result = await session.execute(select(ManagedAccount).where(ManagedAccount.id == account_id))
        account = result.scalar_one_or_none()
        if account is None:
            await message.answer("❌ Account not found.")
            return
        account.notes = note
        account.updated_at = now_utc()
        await session.commit()
    await add_log(message.from_user.id, "UPDATE_NOTE", str(account_id))
    await message.answer("📝 Note updated.")


@dp.message(Command("health"))
async def health_handler(message: Message):
    if not await require_admin(message):
        return
    async with SessionLocal() as session:
        rows = {}
        for value in ("healthy", "degraded", "offline", "unknown"):
            rows[value] = await session.scalar(select(func.count(ManagedAccount.id)).where(ManagedAccount.health == value))
        total = await session.scalar(select(func.count(ManagedAccount.id)))
    await message.answer(
        "💚 <b>Account Health</b>\n\n"
        f"Total: <code>{total or 0}</code>\n"
        f"🟢 Healthy: <code>{rows['healthy'] or 0}</code>\n"
        f"🟡 Degraded: <code>{rows['degraded'] or 0}</code>\n"
        f"🔴 Offline: <code>{rows['offline'] or 0}</code>\n"
        f"⚪ Unknown: <code>{rows['unknown'] or 0}</code>\n\n"
        "Health checks currently validate the manager-side account record; they do not perform Telegram login/session verification."
    )


@dp.message(Command("healthcheck"))
async def healthcheck_handler(message: Message):
    if not await require_admin(message):
        return
    account_id = await command_account_id(message, "/healthcheck 1")
    if account_id is None:
        return
    async with SessionLocal() as session:
        result = await session.execute(select(ManagedAccount).where(ManagedAccount.id == account_id))
        if result.scalar_one_or_none() is None:
            await message.answer("❌ Account not found.")
            return
    try:
        job_id = await create_job("health_check", message.from_user.id, account_id=account_id, payload={"manual": True})
    except Exception as exc:
        await message.answer(f"❌ Could not queue health check: <code>{str(exc)[:500]}</code>")
        return
    await add_log(message.from_user.id, "QUEUE_HEALTH_CHECK", str(account_id), job_id)
    await message.answer(f"📦 Health check queued.\nJob: <code>{job_id}</code>")


@dp.message(Command("tag"))
async def tag_handler(message: Message):
    if not await require_admin(message):
        return
    parts = message.text.split()
    if len(parts) != 3:
        await message.answer("Usage:\n<code>/tag 1 vip</code>")
        return
    try:
        account_id = int(parts[1])
    except ValueError:
        await message.answer("❌ Invalid account ID.")
        return
    tag = parts[2].strip().lower()
    if not tag or len(tag) > 100:
        await message.answer("❌ Invalid tag.")
        return
    async with SessionLocal() as session:
        account = await session.scalar(select(ManagedAccount).where(ManagedAccount.id == account_id))
        if account is None:
            await message.answer("❌ Account not found.")
            return
        exists = await session.scalar(select(AccountTag).where(AccountTag.account_id == account_id, AccountTag.tag == tag))
        if exists is None:
            session.add(AccountTag(account_id=account_id, tag=tag))
            await session.commit()
    await add_log(message.from_user.id, "ADD_TAG", str(account_id), tag)
    await message.answer(f"🏷️ Tag <code>{tag}</code> added to account <code>{account_id}</code>.")


@dp.message(Command("untag"))
async def untag_handler(message: Message):
    if not await require_admin(message):
        return
    parts = message.text.split()
    if len(parts) != 3:
        await message.answer("Usage:\n<code>/untag 1 vip</code>")
        return
    try:
        account_id = int(parts[1])
    except ValueError:
        await message.answer("❌ Invalid account ID.")
        return
    tag = parts[2].strip().lower()
    async with SessionLocal() as session:
        result = await session.execute(select(AccountTag).where(AccountTag.account_id == account_id, AccountTag.tag == tag))
        row = result.scalar_one_or_none()
        if row:
            await session.delete(row)
            await session.commit()
    await add_log(message.from_user.id, "REMOVE_TAG", str(account_id), tag)
    await message.answer(f"🗑️ Tag <code>{tag}</code> removed from account <code>{account_id}</code>.")


@dp.message(Command("tags"))
async def tags_handler(message: Message):
    if not await require_admin(message):
        return
    async with SessionLocal() as session:
        result = await session.execute(select(AccountTag.tag, func.count(AccountTag.id)).group_by(AccountTag.tag).order_by(AccountTag.tag))
        rows = result.fetchall()
    if not rows:
        await message.answer("🏷️ <b>Tags</b>\n\nNo tags created yet.")
        return
    await message.answer("🏷️ <b>Tags</b>\n\n" + "\n".join(f"• <code>{tag}</code> — {count} account(s)" for tag, count in rows))


@dp.message(Command("stop"))
async def stop_handler(message: Message):
    if not await require_admin(message):
        return
    await set_emergency_stop(True)
    await add_log(message.from_user.id, "EMERGENCY_STOP", details="Worker processing paused")
    await message.answer("🛑 <b>Emergency stop activated.</b>\n\nThe worker will pause. Database remains available.")


@dp.message(Command("resume"))
async def resume_handler(message: Message):
    if not await require_admin(message):
        return
    await set_emergency_stop(False)
    await add_log(message.from_user.id, "RESUME", details="Worker processing resumed")
    await message.answer("▶️ <b>System resumed.</b>\n\nThe worker may process queued jobs again.")


@dp.message(Command("queue"))
async def queue_handler(message: Message):
    if not await require_admin(message):
        return
    redis_size = await queue_length()
    async with SessionLocal() as session:
        queued = await session.scalar(select(func.count(Job.id)).where(Job.status == "queued"))
        running = await session.scalar(select(func.count(Job.id)).where(Job.status == "running"))
    await message.answer(
        "📦 <b>Queue</b>\n\n"
        f"Redis waiting: <code>{redis_size}</code>\n"
        f"DB queued: <code>{queued or 0}</code>\n"
        f"DB running: <code>{running or 0}</code>\n"
        f"Processing: {'🔴 Paused' if await emergency_stopped() else '🟢 Enabled'}"
    )


@dp.message(Command("jobs"))
async def jobs_handler(message: Message):
    if not await require_admin(message):
        return
    parts = message.text.split(maxsplit=1)
    status_filter = parts[1].strip().lower() if len(parts) == 2 else None
    valid = {"queued", "running", "completed", "failed", "cancelled"}
    if status_filter and status_filter not in valid:
        await message.answer("Filters: queued, running, completed, failed, cancelled")
        return
    async with SessionLocal() as session:
        stmt = select(Job).order_by(Job.id.desc()).limit(20)
        if status_filter:
            stmt = stmt.where(Job.status == status_filter)
        result = await session.execute(stmt)
        rows = result.scalars().all()
    if not rows:
        await message.answer("📦 No jobs found.")
        return
    lines = ["📦 <b>Recent Jobs</b>", ""]
    for job in rows:
        icon = {"queued": "🟡", "running": "🔵", "completed": "🟢", "failed": "🔴", "cancelled": "⚪"}.get(job.status, "⚪")
        lines.append(f"{icon} <code>{job.job_id}</code> — {job.job_type}\nStatus: <code>{job.status}</code> | Attempts: <code>{job.attempts}/{job.max_attempts}</code>")
    await message.answer("\n\n".join(lines))


@dp.message(Command("job"))
async def job_handler(message: Message):
    if not await require_admin(message):
        return
    parts = message.text.split(maxsplit=1)
    if len(parts) != 2:
        await message.answer("Usage:\n<code>/job JOB_ID</code>")
        return
    job_id = parts[1].strip()
    async with SessionLocal() as session:
        result = await session.execute(select(Job).where(Job.job_id == job_id))
        job = result.scalar_one_or_none()
    if job is None:
        await message.answer("❌ Job not found.")
        return
    await message.answer(
        "📦 <b>Job Details</b>\n\n"
        f"ID: <code>{job.job_id}</code>\n"
        f"Type: <code>{job.job_type}</code>\n"
        f"Status: <code>{job.status}</code>\n"
        f"Account: <code>{job.account_id or 'None'}</code>\n"
        f"Attempts: <code>{job.attempts}/{job.max_attempts}</code>\n"
        f"Created: <code>{job.created_at}</code>\n"
        f"Started: <code>{job.started_at or '—'}</code>\n"
        f"Finished: <code>{job.finished_at or '—'}</code>\n"
        f"Result: <code>{job.result or '—'}</code>\n"
        f"Error: <code>{job.error or '—'}</code>"
    )


@dp.message(Command("canceljob"))
async def cancel_job_handler(message: Message):
    if not await require_admin(message):
        return
    parts = message.text.split(maxsplit=1)
    if len(parts) != 2:
        await message.answer("Usage:\n<code>/canceljob JOB_ID</code>")
        return
    job_id = parts[1].strip()
    async with SessionLocal() as session:
        result = await session.execute(select(Job).where(Job.job_id == job_id))
        job = result.scalar_one_or_none()
        if job is None:
            await message.answer("❌ Job not found.")
            return
        if job.status not in {"queued", "running"}:
            await message.answer(f"ℹ️ Job is already <code>{job.status}</code>.")
            return
        job.status = "cancelled"
        job.finished_at = now_utc()
        await session.commit()
    await add_log(message.from_user.id, "CANCEL_JOB", job_id)
    await message.answer(f"⚪ Job <code>{job_id}</code> cancelled.")


@dp.message(Command("retryjob"))
async def retry_job_handler(message: Message):
    if not await require_admin(message):
        return
    parts = message.text.split(maxsplit=1)
    if len(parts) != 2:
        await message.answer("Usage:\n<code>/retryjob JOB_ID</code>")
        return
    job_id = parts[1].strip()
    async with SessionLocal() as session:
        result = await session.execute(select(Job).where(Job.job_id == job_id))
        job = result.scalar_one_or_none()
        if job is None:
            await message.answer("❌ Job not found.")
            return
        if job.status not in {"failed", "cancelled"}:
            await message.answer("ℹ️ Only failed/cancelled jobs can be retried.")
            return
        job.status = "queued"
        job.error = None
        job.finished_at = None
        await session.commit()
        job_type = job.job_type
    if redis_client is None:
        await message.answer("❌ Redis is offline.")
        return
    await redis_client.rpush(QUEUE_KEY, json.dumps({"job_id": job_id, "type": job_type, "manual_retry": True}))
    await add_log(message.from_user.id, "RETRY_JOB", job_id)
    await message.answer(f"🔁 Job <code>{job_id}</code> queued again.")


@dp.message(Command("active"))
async def active_handler(message: Message):
    if not await require_admin(message):
        return
    parts = message.text.split(maxsplit=1)
    if len(parts) != 2:
        await message.answer("Usage:\n<code>/active -1001234567890</code>")
        return
    try:
        telegram_id = int(parts[1].strip())
    except ValueError:
        await message.answer("❌ Invalid Telegram ID.")
        return
    async with SessionLocal() as session:
        group = await session.scalar(select(TelegramGroup).where(TelegramGroup.telegram_id == telegram_id))
        if group is None:
            group = TelegramGroup(telegram_id=telegram_id, is_active=True, created_by=message.from_user.id)
            session.add(group)
        else:
            group.is_active = True
            group.updated_at = now_utc()
        await session.commit()
    await add_log(message.from_user.id, "ACTIVE_TARGET", str(telegram_id))
    await message.answer(f"✅ Target <code>{telegram_id}</code> is active.")


@dp.message(Command("inactive"))
async def inactive_handler(message: Message):
    if not await require_admin(message):
        return
    parts = message.text.split(maxsplit=1)
    if len(parts) != 2:
        await message.answer("Usage:\n<code>/inactive -1001234567890</code>")
        return
    try:
        telegram_id = int(parts[1].strip())
    except ValueError:
        await message.answer("❌ Invalid Telegram ID.")
        return
    async with SessionLocal() as session:
        group = await session.scalar(select(TelegramGroup).where(TelegramGroup.telegram_id == telegram_id))
        if group is None:
            await message.answer("ℹ️ Target is not registered.")
            return
        group.is_active = False
        group.updated_at = now_utc()
        await session.commit()
    await add_log(message.from_user.id, "INACTIVE_TARGET", str(telegram_id))
    await message.answer(f"🔴 Target <code>{telegram_id}</code> deactivated.")


@dp.message(Command("groups"))
async def groups_handler(message: Message):
    if not await require_admin(message):
        return
    async with SessionLocal() as session:
        result = await session.execute(select(TelegramGroup).order_by(TelegramGroup.id.desc()))
        groups = result.scalars().all()
    if not groups:
        await message.answer("📋 <b>Registered Targets</b>\n\nNo targets registered.")
        return
    lines = ["📋 <b>Registered Targets</b>", ""]
    for group in groups:
        status = "🟢 Active" if group.is_active else "🔴 Inactive"
        lines.append(f"{status}\n📌 {group.title or 'Unknown'}\n🆔 <code>{group.telegram_id}</code>")
    await message.answer("\n\n".join(lines))


@dp.message(Command("logs"))
async def logs_handler(message: Message):
    if not await require_admin(message):
        return
    async with SessionLocal() as session:
        result = await session.execute(select(AuditLog).order_by(AuditLog.id.desc()).limit(20))
        logs = result.scalars().all()
    if not logs:
        await message.answer("📜 No activity logs yet.")
        return
    lines = ["📜 <b>Recent Activity</b>", ""]
    for log in logs:
        lines.append(f"• <b>{log.action}</b> — <code>{log.target or '-'}</code>\n  Admin: <code>{log.admin_id}</code>\n  {log.details or ''}")
    await message.answer("\n".join(lines))


async def main() -> None:
    await create_tables()
    await init_redis()

    bot = Bot(
        token=BOT_TOKEN,
        default=DefaultBotProperties(parse_mode=ParseMode.HTML),
    )

    worker_task = asyncio.create_task(worker_loop())
    scheduler_task = asyncio.create_task(health_scheduler_loop())

    try:
        print("🤖 Bot starting...")
        print("🗄️ PostgreSQL initialized...")
        print("🔴 Redis initialized...")
        await dp.start_polling(bot)
    finally:
        worker_task.cancel()
        scheduler_task.cancel()
        await asyncio.gather(worker_task, scheduler_task, return_exceptions=True)
        await heartbeat("stopped", None)
        await bot.session.close()
        await close_redis()
        await engine.dispose()


if __name__ == "__main__":
    asyncio.run(main())
