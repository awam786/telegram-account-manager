import os


BOT_TOKEN = os.getenv("BOT_TOKEN")
DATABASE_URL = os.getenv("DATABASE_URL")
REDIS_URL = os.getenv("REDIS_URL")

ADMIN_IDS = {
    int(user_id.strip())
    for user_id in os.getenv("ADMIN_IDS", "").split(",")
    if user_id.strip()
}

HEALTH_INTERVAL_SECONDS = int(os.getenv("HEALTH_INTERVAL_SECONDS", "300"))
WORKER_POLL_SECONDS = float(os.getenv("WORKER_POLL_SECONDS", "2"))
JOB_RETRY_DELAY_SECONDS = float(os.getenv("JOB_RETRY_DELAY_SECONDS", "5"))
WORKER_NAME = os.getenv("WORKER_NAME", "telegram-account-manager-worker")

for name, value in (
    ("BOT_TOKEN", BOT_TOKEN),
    ("DATABASE_URL", DATABASE_URL),
    ("REDIS_URL", REDIS_URL),
):
    if not value:
        raise RuntimeError(f"{name} is not configured")

if not ADMIN_IDS:
    raise RuntimeError("ADMIN_IDS is not configured")

if DATABASE_URL.startswith("postgres://"):
    DATABASE_URL = DATABASE_URL.replace("postgres://", "postgresql+asyncpg://", 1)
elif DATABASE_URL.startswith("postgresql://"):
    DATABASE_URL = DATABASE_URL.replace("postgresql://", "postgresql+asyncpg://", 1)
